# 2026-11-24 클라우드 실행 보고

## 하수도 공통 마법 부여·함정·철 열쇠

기준 c2d057d의 기존 82건 중 81 PASS, 1 FAIL이었다. 411의 자동 탐험에서 한 영웅이 출구 전에 사망했다. 협동 층 초기 Actor ID의 배정 순서와 안내기의 동률 표적 선택을 안정화했다. 최종 빌드 5015b18의 기존 82건과 신규 18건이 모두 PASS였다. 오류·실패·건너뜀은 0건이다.

| 검증 | 결과 | 시험 경계 |
|---|---|---|
| 기존 82건 최초 재실행 | FAIL | 411의 정상 시작 경로 1건. 최초 JUnit XML과 로그를 보존 |
| 원본 14종·양쪽 좌석 | PASS | seed 421의 실제 생성 석상과 무기. 선택별 통제 RNG로 28회, 자연 전투·연속 효과·부활 및 이동 충돌은 별도 시험 |
| 황금 미믹과 석상 네 조합 | PASS | 427·428의 실제 위장·기습·보상, 생성 장비 네 조합과 이전 조합·드롭·귀속. 영웅 전용 무기 기술은 미검증 |
| 1↔2층 계단 배치 | PASS | 402–423은 22/22, 424–445는 22/22, 지정 479는 1/1. 45개 모두 2층과 RNG 복원·귀환·다음 행동 |
| 원본 시작 지점부터 걷기 | PASS | 별도 11개 시드. 이동·실제 전투·숨은 문 탐색·계단 동의. 2층 모든 방을 탐험하는 경로는 미검증 |
| 함정 | PASS | 자연 1층 WornDart 양 좌석의 보행·밀치기와 피격. 같은 원본 생성 방에 배치한 추가 10종 × 2좌석의 효과·월드 번들 복원·후속 행동 |
| 철 열쇠 | PASS | 양쪽 좌석 수집·상대 좌석 소비, 재시작, 중복 요청, 층별 수량과 이전 층 문 보존 |
| 독립 TCP JVM과 파일 복구 | PASS | 황금 기습, 421 석상 타격, 다트 피해, 철문 열기 각 1회 HEAD 발행 직후 호스트 프로세스를 종료. 양쪽 좌석 인증, LOOKUP 및 같은 명령 재전송 |
| Desktop 한국어·영어 | PASS | LWJGL과 가상 X11에서 원본 지도와 실제 입력·TCP를 사용. 황금 상자 공개와 재접속, 421 석상 교전, 다트 발동과 잠긴 문. 최초 한국어 석상 촬영에서 다음 행동권 대기가 만료되어 촬영용 관측자 HP를 120으로 준비한 뒤 두 언어로 재실행 |
| 최종 전체 JUnit 및 Android APK | PASS | 100건, 35,244,798 B, v1·v2 서명 |
| Android 설치·터치·화면·Wi-Fi·핫스팟 / 호스팅 Actions | NOT RUN | Cloud JDK·SDK로 빌드하고 패키지와 서명 검사 |

중간 체크포인트 5f2075b에서도 당시 전체 95건과 APK 검사가 통과했다. 최종 APK는 4.0.2-INDEV-sewer-effects, versionCode 922, org.spdcoop.dungeon.indev이다. 빌드 커밋은 `5015b183052c3b406e0e39d5237fba7879e40d63`, APK SHA-256은 `68ebaca303406837f17dbac41f729f114fd6e620ec771e15a3b94ea3beb793f0`, 개발 서명 인증서 SHA-256은 `0dd9070b5f17192a8b07e5ddb6735161b0d2bb6e49013e4d61ca5ee6216ddb53`이다.

| 독립 JVM 시험 모드 | 실제 성공 응답 행동 | 재인증 |
|---|---:|---:|
| unstable | 6 | 2 |
| unstable-receipt | 1 | 2 |
| golden | 4 | 0 |
| goldenreceipt | 1 | 2 |
| dart | 1 | 0 |
| dart-receipt | 1 | 2 |
| iron-door | 3 | 2 |
| door-receipt | 1 | 2 |

이 8개 모드에서 성공 응답 행동은 18건이고 기존 좌석 재인증은 12회다. 강제 종료로 유실된 4개 응답과 영수증 조회는 행동 횟수에서 제외한다. 전체 회귀 소켓 모드는 JUnit 원문에 있다.

```text
mixed native strike markers=[Bleeding, Chill, Elastic, Poison]
natural unstable seat=0 native_hits=3
natural unstable seat=1 native_hits=4
native socket route action_ack_count=149 median_us=14132 p95_us=26650
native socket route moves=121 melee=18 searches=1 casts=1
floor=1 explicit_disk_saves=21 median_us=13300 p95_us=27527 generation_bytes=55805 slot_bytes=111674 active_actors=17 parked_utf8_bytes=0 host_used_heap_bytes=92217888
floor=2 explicit_disk_saves=21 median_us=21766 p95_us=35416 generation_bytes=114368 slot_bytes=228800 active_actors=17 parked_utf8_bytes=37299 host_used_heap_bytes=10087400
ascent_ack_us=84882
```

원본 1층 시작 위치에서의 이동·공격·탐색·마법은 [시드별 집계](docs/coop/sewer-routes.tsv)에, 계단 배치 시험은 [45개 행](docs/coop/sewer-gates.tsv)에 기록했다. 검증 ZIP에는 APK 검사 결과·빌드 커밋·모든 JUnit XML·로그·스크린샷이 들어 있다. APK 파일은 Cloud 결과물에 별도로 보존한다.

|상태|실행한 검사|관측 결과|
|---|---|---|
|PASS|git ls-remote --exit-code --tags 및 git rev-parse HEAD 'v4.0.2^{commit}'|공식 태그와 로컬 커밋 일치. 전체 SHA는 PROGRESS.md에 있다.|
|FAIL|첫 ./gradlew --no-daemon :android:assembleDebug|Java가 Gradle 배포 URL에 직접 연결해 Connection refused. spd-baseline.log.|
|PASS|JDK 설치, sdkmanager, 프록시 적용 후 같은 원본 명령|BUILD SUCCESSFUL, 46 tasks executed. spd-build.log.|
|PASS|scripts/setup-android.sh|CLI 압축 파일 체크섬 검증 및 SDK 구성 확인. SDK XML 버전 경고 발생.|
|FAIL|기본 샌드박스의 ./gradlew --offline --no-daemon :core:test :android:assembleDebug|Gradle 잠금 소켓용 wildcard IP를 열 수 없음. spd-fork.log.|
|PASS|승인된 네트워크 환경에서 같은 offline 명령|독립 Android ID로 빌드 성공. 10 tasks executed, 36 up-to-date. spd-verified.log.|
|PASS|두 APK에 scripts/inspect-apk.sh 실행|aapt 패키지, min/target SDK, 네 ABI 확인. apksigner verify 성공(v1·v2), 크기와 SHA-256 기록.|
|PASS|python3 scripts/audit-engine.py|공식 커밋에서 모든 추적 Java 파일 조회. 직접 표기 325개 파일, 2,159회.|
|NOT RUN|:core:test의 실제 테스트 케이스|Gradle 태스크 결과 NO-SOURCE. 단위·Headless·소켓·스트레스·싱글플레이 회귀 미실행.|
|NOT RUN|GitHub Actions 및 Android 기기|사용자 저장소 미연결. 실기기 없음.|

## 재검토 자료

원본·개발판 패키지와 인증서 및 파일 체크섬은 docs/coop/upstream-apk.txt, docs/coop/fork-apk.txt에 있다. 빌드 시도별 전체 Gradle 출력은 docs/coop/logs/에 보존했다.

주요 추가 실행 명령은 git clone --depth 1 --single-branch --branch v4.0.2, git switch -c coop/baseline, java -version, sdkmanager --sdk_root=… 'platforms;android-36' 'build-tools;36.0.0', gh api user, git status --short, git diff --check다. 실제 사용한 JDK/SDK 설정과 재현 명령은 BUILD.md를 따른다.

## Phase 2 후속 실행 — 2026-11-24

- PASS — gh api user, gh api repos/jwgobaek/SPD-Coop, git fetch --no-tags coop master 및 merge-base --is-ancestor. 사용자 jwgobaek, master 57a4e06.
- FAIL — git push -u coop coop/baseline. HTTP 403 Permission denied. Actions 실행 목록은 조회 가능했고 0건이었다.
- FAIL → PASS — :core:test 첫 실행에서 Game.version 미설정으로 DeviceCompat.isDebug 초기화 실패. 테스트 부트스트랩에 실제 버전을 설정했다.
- PASS — 별도 v4.0.2 worktree에 테스트 의존성과 러너만 적용하여 ./gradlew --offline :core:test 실행. 지형 배열의 Arrays.hashCode가 -585159512였다. 개발 checkout에서 ./gradlew --offline :core:cleanTest :core:test :android:assembleDebug 실행. 다른 JVM에서 같은 값과 실제 저장·복원 지형 배열을 확인했다. JUnit XML 1건, 실패/오류/스킵 0. 원본 Java 런타임 클래스 변경 없음.
- NOT RUN — GitHub Actions, 실기기, 전투·턴·보스·협동 회귀. 이번 테스트가 검증한 복원 대상은 첫 층의 지형이다.

## Phase 2 엔진 회귀 및 원격 검증 — 2026-11-24

시작점 2f81e97. gh api user, 레포 메타데이터, git ls-remote --heads coop 확인 후 git push --atomic -u coop coop/baseline coop/phase2 성공. gh pr create --draft로 PR #1 생성. 이후 개발 브랜치에 일반 push. 기준 master는 57a4e06 유지.

|상태|증거와 범위|
|---|---|
|PASS|기존 :core:cleanTest :core:test부터 재실행. 전사 402 지형 해시 및 저장 지형 비교 통과.|
|FAIL → PASS|실제 이동·공격에서 HeroSprite 캐스팅, HUD 및 입력 selector 부재를 확인. 표시 객체가 존재할 때만 표시 호출을 수행하도록 조정. 원본 Hero.handle/act/onAttackComplete, Food.execute 및 시간 계산을 실행했다.|
|FAIL → PASS|시드만 고정한 다중 시드 지문에서 guidebook 위치 차이 발견. EntranceRoom.placeEarlyGuidePages는 별도 무시드 RNG를 사용한다. 마법사 2402·도적 3402의 튜토리얼 완료 상태를 고정하고 공식 태그의 독립 JVM에서 각 3회 같은 전체 지문을 확인했다. 지형·출입구·HP·몹 종류/좌표·바닥 아이템 종류/좌표/수량/강화·초기 장비를 개발판과 비교했다.|
|PASS|행동/저장 — 가속 이동 비용, 공격 완료 전후 피해·시간, 식량 소모, 강화 무기·장비 상태, HP, 좌석 도입 전 영웅 ID, 적 ID/HP/위치, 탐험 배열, 두 층 왕복과 복원 후 다음 이동.|
|PASS|Actor.process 스레드로 두 턴 휴식. 버프 만료 시점, 경과 시간 리베이스 불변식, 스레드 종료 검증. 쥐 AI의 표적 선택, 연속 네 번의 공격 비용 및 영웅 피해 검증.|
|PASS|Goo 피해·격노·층 봉쇄/해제·열쇠, 축복 앙크 1회 소모와 원본 HP 회복, 최종 사망·랭킹·저장 슬롯 제거, Dungeon.win의 승리 기록.|
|PASS|코드 커밋 f96289cd1439e0fc4560ebc256d1293ebac4343f에서 scripts/verify-android-build.sh 실행. 9 JUnit cases, 실패·오류·스킵 0. 디버그 APK 36,841,768 bytes, SHA-256 a9b558541d5431bd94972ea9b1d7ae226a59d5c242a8c7d99188cb1ef0c5d299, aapt 및 apksigner v1/v2 성공.|
|FAIL|gh workflow run android.yml --ref coop/phase2는 404. master에서 파일 조회 404, 개발 브랜치 파일 조회 성공. 관리 설정 GET은 403, 요구 권한 administration=read.|
|NOT RUN|GitHub REST 실행/Artifact 목록 모두 0건. GitHub 호스팅 빌드 및 실기기 검증 미실행. 승리 화면 버튼·전체 던전 완주, 협동 및 스트레스 테스트는 이 단계에 포함되지 않았다.|

Headless 기준은 실제 엔진 생성·행동·저장·종료에 적용한다. 화면 효과의 표시, 실제 터치, 몬스터 전체 종의 행동은 별도 검증 대상이다. 시드 지문 테스트는 JVM을 클래스별로 분리했고 기존 난수 구현을 유지했다.

## Phase 3 오프라인 두 영웅 — 2026-11-24

기준 브랜치 `coop/phase2`의 원격 HEAD는 `61deb846c4668b16272baec91c32ba21cd4d1c7b`였다. 변경 전 9건을 재실행했다. 아래 최종 빌드 대상은 `8207671d628240d2310f230503ca8ec52d865d53`이다. 테스트 엔진은 libGDX Headless, 실제 Dungeon/Level/Hero/Actor이며 클래스 단위로 JVM을 분리한다.

|상태|검증 대상|실제 결과|
|---|---|---|
|PASS|변경 전/후 단일플레이|기존 JUnit 9건을 보존했다. 시드 지형·장비·몹 지문, 이동·버프·공격·저장/복원, 원본 Actor 스레드, 보스·사망·승리 회귀 모두 통과했다.|
|PASS|두 좌석의 생성 및 초기화|같은 Level 인스턴스와 지형, 같은 몹 집합, 서로 다른 통행 가능한 위치·Actor ID, player ID/좌석 매핑, 반대 직업, 첫 영웅의 HP·위치·무기·버프 등록, 전역 골드·통계·제한 아이템 기록 및 다음 RNG 값 보존.|
|PASS|이동·시간·권한|두 영웅의 독립적인 한 칸 이동, 벽·점유 위치 거절, 잘못된 좌석/오래된 턴 거절. 가속 이동 비용을 원본 speed와 비교했고 게스트의 감속이 다음 행동 시각에만 반영됨을 확인했다.|
|PASS|인벤토리·장비·식량|원본 더미에서 획득·소멸, 두 영웅이 같은 더미에 접근하는 경쟁, 타인 소유 아이템 거부, 서로 다른 강화 수치가 있는 무기 장착, 양쪽의 식량 수량·섭취 횟수 검증.|
|PASS|기본 전투·경험치|동일한 쥐를 두 영웅이 공격. 실제 명중·피해·attackDelay와 중복 요청 거절 확인. 쥐가 게스트를 선택해 공격한 동안 호스트 HP 보존. 쥐의 4회 행동 시간과 게스트 처치 1회의 XP·등록 해제 검증.|
|PASS|중단 및 저장 격리|외부 스레드 요청·중복 스케줄러 진입·싱글 저장/삭제·층 전환 거절. 게스트 치명상과 미지원 Crab의 행동 시도에서 세션 종료. 기존 싱글 슬롯의 테스트 내용과 도감 식량 사용 횟수, 배지 상태, 기본 파일 경로 복원 확인.|
|PASS|반복 행동·종료|시드 402/2402/3402 각각 두 좌석 총 120회(호스트 대기 60, 게스트 왕복 이동 60). 시간 역행·차례 누락·점유 불일치·식량 복제 없이 시드당 원본 게임 시간 60 경과. 전용 엔진 스레드 종료 확인.|
|PASS|전체 및 반복|최종 빌드 시 JUnit 19/19 통과(기존 9 + 신규 10). 이어 새 JVM에서 협동 10건을 3회 재실행해 30/30 통과. 이 네 번의 실행에서 반복 시나리오의 유효 행동은 총 1,440회였다. XML별 오류·실패·스킵 모두 0.|
|PASS|Android 디버그 APK|36,795,935 bytes, SHA-256 `8bafb66c7056cc48dccd7e36b2714ed7852c60175ddbb745f23de5633964ae61`. aapt로 `org.spdcoop.dungeon.indev`, 4.0.2-INDEV(922), minSdk 21, targetSdk 36 확인. apksigner v1/v2 서명 검증 성공.|
|PASS|참조 색인 재현|원본 커밋을 대상으로 역할 표를 다시 생성해 바이트 단위로 비교. 직접 참조 2,159개·325개 파일 일치. 의미 분류는 수동 검토와 구분되는 1차 분류다.|
|NOT RUN|GitHub 호스팅·실기기·LAN·콘텐츠 완주|코드 커밋의 일반 푸시 후 Actions API 브랜치 실행 0건. Cloud APK를 검사했다. Android 기기 설치·화면·터치, LAN, 협동 전체 던전 완주는 실행하지 않았다.|

개발 중 실제 공격 테스트에서 새 몹을 감지한 `Hero.checkVisibleMobs`가 입력 직후 요청을 취소하는 경로를 확인했다. 새 적의 가시성을 명시적 입력 **전에** 갱신했다. 사냥꾼의 장갑 공격은 명중해도 피해가 0일 수 있어 피해 검증에서는 실제 RNG에 고정 시드를 주고 원본 방어·피해·시간 계산을 그대로 실행했다. 버프, 음식, 초기 장비, 배지와 도감 캐시의 주체를 점검해 게스트 사용이나 세션 종료가 다른 소유자의 상태에 적용되지 않도록 했다. apksigner의 META-INF 경고와 v3/v4 미적용은 원문에 포함했다.

### 재현 명령과 결과물

아래는 이 Cloud 작업에서 사용한 주요 명령이다. `/tmp/spd-env`는 이 인스턴스의 JDK/SDK/Gradle 경로 설정이며 새 환경은 BUILD.md 절차를 따른다.

```bash
git ls-remote --heads coop master coop/phase2 coop/phase3
git switch -c coop/phase3 61deb84
source /tmp/spd-env
./gradlew --offline :core:cleanTest :core:test
./gradlew --offline :core:test
python3 scripts/classify-hero-references.py > docs/coop/hero-roles.tsv
git diff --check
scripts/verify-android-build.sh /workspace/deliverables/phase3-engine
./gradlew --offline :core:cleanTest :core:test --tests '*CoopSessionTest'
git push -u coop coop/phase3
gh api 'repos/jwgobaek/SPD-Coop/actions/runs?branch=coop%2Fphase3&per_page=5'
```

`docs/coop/phase3-cloud-evidence.zip`에는 빌드 로그, APK 패키지·서명 출력, APK SHA256SUMS, 빌드 커밋, JUnit XML 및 추가 3회의 로그/XML이 들어 있다. ZIP 검사와 APK 체크섬 재검증 모두 통과했다. ZIP의 SHA-256은 `bb454bdca97b76d6436782b3e3c3b3b33b3176f7db0e04eaf354f4d3a6b87c1d`이다. APK는 Cloud 작업 공간의 `/workspace/deliverables/phase3-engine/android-debug.apk`에 있다. 영구 Git 보존 범위는 소스, 보고서와 증거 ZIP이다.

## Phase 4 LAN — 2026-11-24

시작 시 로컬/원격 coop/phase3는 95b42adef88ac2ea3abcc94aa4f7e8d8f908f5cd였다. 트리는 깨끗했고 원격 coop/phase4는 없었다. 분기 후 기존 19건을 먼저 재실행했다. 최종 검증 커밋은 5aac3b91de33e5c92be24cc02ba14a4154988c46이다.

|상태|실행 경로|관측 결과|
|---|---|---|
|PASS|기존 :core:test|최종 빌드에서 싱글 9건 + 협동 엔진 10건 통과. 기존 테스트와 Actor/CoopSession 소스를 보존했다.|
|PASS|LanIntegrationTest → LanScenarioClient|JUnit 호스트 JVM에서 실제 HeadlessApplication·CoopSession과 I/O 워커를 실행했다. 별도 java 프로세스에서 loopback 호스트 컨트롤러와 게스트 클라이언트를 각각 TCP로 연결했다. 테스트용 로컬 방장 권한은 자식의 stdin으로 전달했다. 클라이언트 JVM에서 게임을 초기화하지 않았다.|
|PASS|UDP·TCP·로비|loopback UDP 검색, TCP 직접 접속, 동일 방의 게스트 참가/종료 50회, 좌석 발급, 정원·중복 참가·게스트 시작·준비 전 시작 거부, 직업·준비 토글, 실제 두 영웅 생성, 시작 후 잠금과 검색 중단을 확인했다.|
|PASS|원본 게임 행동|한 세션에서 APPLIED 310회(방장 155, 게스트 155). 실제 이동·대기·근접 공격·바닥 무기 획득·장착·식량 섭취를 포함한다. 호스트 테스트가 생성된 층에 실제 Shortsword와 HP 1 Rat를 배치했다. 매 승인 시 actor 점유와 게임 시간, 턴 증가를 확인하고 실제 장비·식량·몬스터 사망을 검사했다.|
|PASS|권한·재전송|타 좌석 요청, 잘못된 Actor ID, 올바른 신원을 가진 비활성 좌석, 타인의 아이템 핸들, 범위 밖 이동, 미지원 행동, 과거 턴·동일 요청 ID·이전 세션·버전 불일치를 거부했다. WAITING에는 다른 좌석의 아이템 목록이 없었다.|
|PASS|경계·오류|분할 프레임, 연속 프레임, 잘린 프레임과 과대 길이, 미완성 헤더의 유휴 만료 및 다른 정상 클라이언트의 PONG을 확인했다. LanBoundaryTest 5건에서 UDP 중복 제거, UDP 포트 점유 중 TCP 성공, 응답 없는 서버의 타임아웃과 접속 거절 코드, 64개 입력 큐 경계, 실제 읽지 않는 TCP 피어의 출력 정체 종료를 확인했다.|
|PASS|단절·정리|게스트 소켓 종료 후 PAUSED, 방장 BYE 후 CLOSED. 자식 JVM 종료 코드 0, LAN 워커 종료, Actor.processing() 해제, Dungeon.coop 정리를 확인했다.|
|PASS|최종 APK와 증거|JUnit 25건(기존 19 + 신규 6), 실패·오류·스킵 0. 4.0.2-INDEV(922), org.spdcoop.dungeon.indev, 36,807,237 bytes. aapt 패키지/minSdk 21/targetSdk 36 확인, apksigner v1·v2 검증 성공. APK SHA-256 ad6c59f77a7fff1592eb6093680400848a784d56b73b801841739d70b53de0c6.|
|NOT RUN|외부 환경|GitHub 호스팅 Actions 실행 0건. Android 기기 설치·화면·Wi-Fi 브로드캐스트·핫스팟·OS별 로컬 권한은 실기기 검증 대상이다. 패킷이 전혀 도달하지 않는 실제 무선망의 TCP 연결 타임아웃도 재현하지 않았다.|

첫 고속 통합 시도에서는 기대한 310회 중 86회만 관측되어 FAIL이었다. 테스트 클라이언트의 STATE·재전송 검사가 정상 요청 예산 안에서 실행되도록 속도를 조절하고, 자식 프로세스의 최종 종료 코드와 오류 출력을 검사했다. 운영 측의 요청 제한과 310회 통과 조건은 유지했다. UDP 바인딩 실패가 TCP까지 닫던 경로도 수정하고 점유된 UDP 포트에서 실제 TCP 왕복을 확인했다.

주요 실행 명령은 다음과 같다. Java 및 SDK 설정은 BUILD.md를 따른다.

```bash
git ls-remote --heads coop coop/phase3 coop/phase4
git switch -c coop/phase4 95b42ad
source /tmp/spd-env
./gradlew --offline :core:cleanTest :core:test
./gradlew --offline :core:test --tests '*LanIntegrationTest'
scripts/verify-android-build.sh /workspace/deliverables/phase4-verified
git push -u coop coop/phase4
gh api 'repos/jwgobaek/SPD-Coop/actions/runs?branch=coop%2Fphase4'
```

LanRoom.pump/dispatch/action/view/close가 좌석·로비·실제 엔진 실행을, LanTransport.run/service/pollDiscovery가 소켓·프레임·제한 큐를, LanClient.discover/request/exchange가 검색·직접 접속·응답을 담당한다. core/build.gradle에는 자식 JVM용 테스트 클래스패스를 설정했다. 테스트 파일은 LanIntegrationTest.java, LanScenarioClient.java, LanBoundaryTest.java다.

[검증 ZIP](docs/coop/phase4-cloud-evidence.zip)에는 최종 빌드 로그, 모든 JUnit XML, APK 검사 결과·체크섬·소스 커밋이 있다. ZIP SHA-256은 01abca1a3ddf6d0e277f7532b6f721b97a0f1ff61816887a58cad7f260eab020이다. sha256sum -c와 unzip -tq가 통과했다. APK는 /workspace/deliverables/phase4-verified/android-debug.apk에 있다.

## Phase 5 — 확정 행동과 좌석별 공개 상태

시작 시 로컬 HEAD와 원격 coop/phase4가 모두 757a4a7c38ff641417b2f7e95c265a4531c0a095였고 작업 트리는 깨끗했다. 기존 25건을 먼저 실행한 뒤 SYNC1을 별도 브랜치에 구현했다. 최종 검증 대상은 18700148a3770cc050087d72c14e39a06e342281이다.

### 검증 방법

- SyncIntegrationTest.normalSynchronizedGameAcrossSocket은 실제 Headless 호스트 JVM과 별도 클라이언트 JVM에 두 TCP 좌석을 둔다. 양쪽이 직접 만든 DisplayReplica를 읽어 현재 활성 좌석에서 SeatActions.Pending을 제출한다. 호스트는 원본 턴·시간을 별도로 검사한다. 중간에 실제 Actor.fixTime을 실행하고 누적 시간과 이후 상태 버전의 연속성을 검사한다.
- committedViewsAcrossThreeIndependentClientRuns는 세 번 새 실제 방과 자식 JVM을 만든다. 생성된 첫 층에 실제 일반 식량·근접 무기·쥐를 배치하고 게스트에게 가속을 부여한다. 여섯 행동을 실제 CoopSession.act로 처리한다. 바닥 식량이 기존 스택에 병합되고 합쳐진 ID가 사라지는지, 수량 2에서 1로 줄어드는지, 무기의 귀속·장착과 쥐 처치가 실제로 일어났는지 확인한다.
- 같은 논리 행동의 영수증을 응용 계층에서 버리고 지연 후 동일 좌석의 같은 TCP 연결에서 새 request ID로 재조회한다. 이미 지난 턴의 캐시 결과, 내용 충돌, 다른 좌석의 조회, 타인 소유·퇴역한 아이템 ID, 이전 세션과 오래된 상태·턴, 캐시 64개를 지난 과거 ID를 검사한다. 기존 ACT로 동기화 방의 검사를 우회할 수도 없다.
- 실제 TCP로 받은 변경분 두 개를 표시 모델에 순서 반대로 전달하고, 정상 순서 및 중복도 적용한다. 누락 후 새 스냅샷으로 복구하며 최신 좌석·턴에서 다음 명령이 승인되는지 확인한다. 실제 스냅샷 조각의 마지막 바이트를 클라이언트에서 손상시켜 독립적인 SHA 검증과 전체 재요청을 확인한다. 응답 유실·중복·순서 변경·손상은 TCP 수신 후의 응용 계층 오류 주입이다.
- 오류 사례에서는 지원 범위 밖의 실제 Crab을 스케줄러에 등록한다. WAIT가 원본 행동 시간을 이미 소모한 뒤 다음 Actor 처리 중 오류가 발생한다. 호스트의 실제 시간을 확인하고 HALTED_UNCERTAIN을 재조회한다. 양쪽의 PAUSED와 ENGINE_ERROR, 행동자 한 명에게만 제공되는 영수증을 검사한다. 이 중단 시도를 정상 확정 횟수에 포함하지 않는다.
- directSightPrivacyAndLossOnGeneratedFloor는 원본 Level에 차폐 벽·비밀 문·숨은 함정과 몹을 배치한 뒤 두 실제 Hero의 공개 상태를 비교한다. 자기 쪽의 HP 변경·표시 버프, 반대편 가방·바닥 아이템·캐릭터·지형의 비공개, 시야에서 나간 몹의 관측 상실, 가려진 후 사라진 몹의 사망 미통지, 전체 재동기화 시 정보 제한을 확인한다.
- DisplayReplicaTest는 다중 조각·불완전한 조립·순서·토큰·개수 상한, 같은 버전의 손상된 상태 본문, 다른 좌석과 과대 상태, 닫힌 모델을 검사한다. 손상된 상태는 기존 이미지 객체를 교체하지 않는다. 기존 LanBoundaryTest와 v1의 프레임 크기 제한 검증도 함께 실행한다.

### 재현 및 변경 파일

```bash
git ls-remote --heads coop master coop/phase4 coop/phase5
git switch -c coop/phase5 757a4a7
source /tmp/spd-env
./gradlew --offline :core:cleanTest :core:test
./gradlew --offline :core:test --tests '*SyncIntegrationTest' --tests '*DisplayReplicaTest'
scripts/verify-android-build.sh /workspace/deliverables/phase5-verified
```

- LanRoom.synchronizedGame/dispatch/pump, LanClient.synchronizedGame/exchange 및 LanTransport.service가 협상과 제한된 프레임을 처리한다.
- RoomSync.action/apply/commit/sync/part, SeatActions.prepare/Pending.submit이 확정·결과 조회와 전송의 경계다.
- SeatProjection.capture/resolve, StateImage.encode/hash, DisplayReplica.refresh/apply/Assembly가 서버 공개 범위와 클라이언트 모델을 구현한다.
- Level.updateDirectSight/updateFieldOfView가 기본 시야 계산을 공유한다. CoopSession.basicMob과 Mob.wasDefeatedBy는 검증된 몹 종류와 실제 직접 처치를 식별한다.
- 신규 테스트·러너는 SyncIntegrationTest, SyncScenarioClient, ProjectionChecks, DisplayReplicaTest다.

### 최종 실행 결과

|상태|검증|실제 결과|
|---|---|---|
|PASS|기존 25건|싱글플레이 9, 협동 엔진 10, LAN 6 통과. 기존 v1 행동 310회 및 로비 참가·종료 50회를 다시 수행했다.|
|PASS|신규 4건|정상 독립 JVM 시나리오, 장애 포함 3개 세션, 원본 시야·관측 상실·프라이버시, 조각·모델 무결성 검증이 통과했다. 전체 JUnit 29건에서 실패·오류·스킵 0.|
|PASS|정상 SYNC1|320회 확정, 요청 975건. 거부·캐시 재응답·재동기화·응답 유실·엔진 중단 각 0건.|
|PASS|장애 SYNC1|세션당 341회 확정, 요청 1,131건, 거부 55건, 캐시 재응답 26건, 전체 재동기화 2회, 응용 계층 응답 유실 1회, 부분 적용 후 엔진 중단 1회. 3개 JVM 시나리오에서 같은 집계 확인.|
|PASS|SYNC1 합계|정상 확정 1,343회, 요청 4,368건, 거부 165건, 캐시 재응답 78건, 전체 재동기화 6회, 응용 계층 응답 유실 3회, 실행 중단 3회. 요청 수에는 조회·조각·로비도 포함한다. 충돌·만료는 거부, 기존 영수증 재반환은 캐시로 센다. 정상 행동 집계에서 중복·중단과 v1 회귀는 제외했다.|
|PASS|APK|4.0.2-INDEV(922), org.spdcoop.dungeon.indev, 36,818,193 bytes, minSdk 21, targetSdk 36. apksigner v1/v2 성공. SHA-256 554e06c844c3a37315c3039c6d428c5bd3860a47516f424f89a5dcdc65e342c0.|
|NOT RUN|외부 검증|coop/phase5 일반 푸시 후 GitHub Actions의 브랜치 실행 기록 0건. 실제 Android 설치·화면·터치·무선 LAN과 재접속은 미검증이다.|

빌드 스크립트 종료 코드 0. APK 파일에 sha256sum -c, 증거 ZIP에 unzip -tq를 실행해 통과했다. [최종 빌드 로그·JUnit XML·패키지와 서명 검사·소스 커밋](docs/coop/phase5-cloud-evidence.zip). ZIP SHA-256은 a82bb060ac2581b227074313f059bf46432f2205705d79f92775f7ab067911e7이다. APK는 Cloud 작업 공간의 /workspace/deliverables/phase5-verified/android-debug.apk에 있다.

## Phase 6 — 2026-11-24

기준 브랜치 coop/phase5와 실제 원격 d86d21ffb8ab2203077dc6bf86e7a0efc711bc19를 확인했다. 아래 최종 수치는 엔진 커밋 53770eabfd0c40ead0d4d1848ddf480c2743930b의 단일 Cloud 검증 빌드에서 얻었다. 단계별 반복 실행은 최종 합계에 더하지 않았다.

| 결과 | 실행 | 관측 |
|---|---|---|
| PASS | 변경 전 전체 회귀 | 싱글 9, 협동 엔진 10, LAN 6, 동기화 4. 총 29건 |
| PASS | 6A 체크포인트 | 전체 29건. 실제 벽 차폐, 다른 좌석의 숨은 몹·더미 제외, 시야 밖에서 지형을 수정한 뒤 원래 기억 유지, 스냅샷 복원과 재관측 갱신을 검사 |
| PASS | 6B 체크포인트 | 선택 회귀 13건. 벽으로 분리한 두 전투, 표적 변경, 경계 병합·분리 5회, 몹 사망, Actor 집합·시간·턴·HP 불변 검사 |
| PASS | 6C 체크포인트 | 선택 회귀 14건. 원본 가방에 식량 스택 병합, 한 단위 드롭, 분할 후 새 ID와 소유권, 타인 가방 수집 실패, 소유자가 다른 바닥 스택 공존, 원본 장비 해제와 재장착 |
| FAIL → PASS | 6D 체크포인트 | 테스트에서 외부 강제 사망으로 취소된 입력 차례를 곧바로 사용해 좌석 -1 오류가 났다. 호스트의 외부 효과 묶음을 finishEffects로 마친 뒤 생존자의 실제 차례를 검증했다. 수정 후 선택 회귀 15건 통과 |
| FAIL → PASS | 동일 몹 교전 소멸 검사 | 두 영웅의 실제 공격을 받은 몹의 최근 교전이 만료된 후, 테스트 구역에 다른 생성 몹이 접근해 새 교전이 형성될 수 있었다. 단일 표적 테스트에서 다른 몹을 격리했다. 엔진의 표적 선택과 구역 소멸 조건을 유지한 채 선택 회귀 16건 통과 |
| PASS | 최종 원본 회귀 및 확장 | 기존 29건과 새 JUnit 메서드 5건, 합계 34건. 실패·오류·스킵 0. 기존 치명상 중단 기대값은 새로운 DEAD·동료 진행·과거 턴 거부 검사로 변경했다. 싱글플레이 축복 앙크·최종 사망·슬롯 정리 회귀도 통과 |
| PASS | 엔진 세부 검증 | 100, 17, 10, 9, 3, 2, 1과 큰 정수의 부활 HP 및 최대 HP 상한, 실제 Rat 근접 공격·Poison.act 치명상, 사망 후 반복 die, 거리·턴·자원 검사, 동결 시계 리베이스와 부활 후 행동, 앙크 1회 소모, 공동 표적에 대한 실제 공격을 검사 |
| PASS | 원본 Foresight 및 공개 범위 | 게스트에 실제 Foresight를 부여하고 원본 search로 차폐 너머 지형만 파악했다. 호스트의 mapped와 원본 level.mapped 배열이 변하지 않는지 확인했다. 현재 시야의 숨은 더미, 비공개 인벤토리, 은폐된 몹, 시야를 떠난 몹은 공개 대상에서 제외됐다. |
| PASS | 이전 독립 JVM 시나리오 | v1 실제 행동 310회 및 로비 50회, 기존 SYNC1 행동 1,343회. 응답 유실·재전송·과거 버전과 엔진 중단 회귀 통과 |
| PASS | Phase 6 독립 JVM | 아래 세 시나리오, 합계 1,023회. 주어진 게임 행동으로 구역을 합치고 분리한 뒤 실제 아이템·부활·전멸까지 확인 |
| PASS | Android Cloud 빌드 | 4.0.2-INDEV, versionCode 922, org.spdcoop.dungeon.indev, minSdk 21, targetSdk 36, 36,823,839바이트. 디버그 서명 v1·v2를 검증하고 체크섬을 다시 확인했다. apksigner의 META-INF 경고 및 v3/v4 미적용은 apk.txt에 있다. |
| NOT RUN | GitHub Actions | 엔진 커밋 푸시 후 브랜치 실행 기록 0, 등록 워크플로 0. android.yml 수동 실행은 조회 단계에서 HTTP 404였다. 포크의 관리자 설정은 확정하지 않았다. GitHub Actions APK 아티팩트는 없다. |
| NOT RUN | 실기기 | Android 설치·화면·터치·무선 Wi-Fi·핫스팟·기기별 성능. 협동 UI, 저장 및 재접속은 후속 단계다. |

### 독립 프로세스 시나리오

RuleIntegrationTest는 HeadlessApplication 호스트에 실제 생성된 첫 던전을 열고 결정적 검사용 지형, 분리벽·통로, 원본 Rat 두 마리, 일반 식량과 앙크를 배치했다. 다른 생성 몹은 이 시나리오에서 제외했다. 두 Rat가 일정 시간 제자리에 있도록 처음 행동을 지연했고 부활·전멸 지점에서는 테스트 Actor가 원본 공격·피해 함수를 호출했다. 일반 몹의 자율 AI와 무작위 월드 회귀는 기존 테스트가 별도로 실행했다. 별도 JVM의 RuleScenarioClient가 두 TCP 좌석으로 접속하고 표시 모델에서 행동을 선택했다.

| 시드 | 방장 / 게스트 | 확정 행동 | 전송 요청 | SYNC·PAGE 조회 | 거부 | 캐시 응답 | 재동기화 | 부활 |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| 402 | 전사 / 사냥꾼 | 341 | 1,049 | 694 | 1 | 2 | 1 | 1 |
| 2402 | 사냥꾼 / 전사 | 341 | 1,049 | 694 | 1 | 2 | 1 | 1 |
| 3402 | 전사 / 사냥꾼 | 341 | 1,049 | 694 | 1 | 2 | 1 | 1 |
| 합계 | | **1,023** | **3,147** | **2,082** | **3** | **6** | **3** | **3** |

각 실행에는 일반 APPLIED 340회와 파티 전멸을 확정한 마지막 행동 1회가 포함된다. 로비·협상 요청은 총 33건이다. 실제 턴·버전이 거부와 재전송에서 증가하지 않는지 확인했다. 클라이언트에서 수신한 스냅샷 조각을 한 차례 손상시켜 재동기화를 일으켰다. 복구된 상태 행·해시와 기존 표시 상태를 비교하고 이후 행동을 계속했다. 호스트에서는 실제 구역 수, HP 17 → 5, 인벤토리에서 사라진 앙크, 최종 행동 횟수를 대조했다. 두 프로세스 모두 정상 종료했다.

### 재현과 결과물

```bash
git ls-remote coop refs/heads/coop/phase5 refs/heads/coop/phase6
git switch -c coop/phase6 d86d21f
source /tmp/spd-env
./gradlew --offline :core:cleanTest :core:test
./gradlew --offline :core:cleanTest :core:test --tests '*CoopSessionTest' --tests '*SyncIntegrationTest.directSight*' --tests '*SchedulerRegressionTest'
./gradlew --offline :core:cleanTest :core:test --tests '*CoopSessionTest' --tests '*LanIntegrationTest' --tests '*SyncIntegrationTest.directSight*'
./gradlew --offline :core:cleanTest :core:test --tests '*CoopSessionTest' --tests '*EndgameRegressionTest' --tests '*SyncIntegrationTest.directSight*'
./gradlew --offline :core:cleanTest :core:test --tests '*RuleIntegrationTest'
scripts/verify-android-build.sh /workspace/deliverables/phase6-verified
git diff --check
git push -u coop coop/phase6
gh workflow run android.yml --repo jwgobaek/SPD-Coop --ref coop/phase6
```

최종 APK SHA-256은 `690e3c4070a5401c549cd31400708e6e011dd9c6932d985d984d2275b29a642a`이다. Cloud 경로는 `/workspace/deliverables/phase6-verified/android-debug.apk`다. 증거 ZIP은 최종 JUnit XML·빌드·서명 로그·소스 커밋·변경 파일과 중간 실패 및 재검증 기록을 포함한다. ZIP 무결성 검사와 APK의 sha256sum -c가 통과했다. ZIP SHA-256은 `d8c7330421bfd252c34b928415f7315ace96d380a116bf3817879fdd74cc2a27`이다. [Git에 보존한 검증 ZIP](docs/coop/phase6-cloud-evidence.zip)

## Phase 7 클라우드 검증 결과

빌드 대상은 `da173259ca546d1e289197d4336a4e5421c83c10`이다. 같은 커밋으로 원본 JUnit 회귀, 협동 저장·소켓 검사 및 Android APK 검사를 실행했다.

| 검사 | 상태 | 실제 결과 |
|---|---|---|
| 변경 전 기준선 | PASS | 기존 34건, 실패·오류·스킵 0 |
| 7A·7B·7C·7D 단계별 실행 | PASS | 7A 수정 후 16건, 7B 19건 및 보강 5건, 7C 6건, 7D 최종 집중 검사 10건. 각 실행의 XML을 ZIP에 보존 |
| 최종 전체 JUnit | PASS | 기존 34건과 신규 10건. 총 44건, 실패·오류·스킵 0 |
| 일반 체크포인트 | PASS | 두 시드·양쪽 직업 배치에서 파일로 저장하고 엔진을 닫은 후 20회 복원. 실제 다음 Actor와 시간 확인 후 20회 행동. 전투 불능·부활 후 상태와 파티 전멸 복원 별도 검사 |
| 독립 JVM 재시작 | PASS | 호스트/클라이언트 JVM을 각각 12회 기동. 초기 게임 이후 디스크에서 11회 재개. 두 좌석의 확정된 공개 상태를 개인 표시 모델과 비교 |
| 연결 재인증 | PASS | 주 시나리오에서 실제 새 TCP 연결 54건을 기존 좌석에 연결. 별도 인증 테스트에서 잘못된 서명·좌석·중복 연결·신규 참가·다른 좌석의 확인 해시 거부 |
| 호스트 네트워크 행동 | PASS | 성공 응답을 받은 행동 1,019건. 응답 전 강제 종료 후 검증한 부활·대기 영수증 2건. 확정 합계 1,021건 중 최초 호스트 재시작 이후 1,006건. 조회·거부·롤백된 메모리 변경은 집계에서 제외 |
| 행동 후 단절과 재조회 | PASS | 획득·공격·식량의 확정 뒤 소켓을 닫고 재접속. 동일 행동 재제출과 LOOKUP에서 기존 결과 반환. 부활은 실제 저장 직후 응답 전에 종료하여 HP 5와 앙크 소모 1회를 새 호스트에서 검증. 1,000회 추가 진행 후 오래된 영수증 EXPIRED |
| 강제 종료 | PASS | 실제 호스트 JVM 6회. 부활 저장 직후 응답 전, 장시간 진행의 마지막 응답 후, 기록 중·검증 중·HEAD 교체 전·후. 별도 파일 계층 시험에서 독립 작성자 JVM 4회 강제 종료 |
| 쓰기 실패·손상 | PASS | 실패를 주입한 행동에는 CHECKPOINT_FAILED를 반환했고 재시작 후 같은 턴과 UNKNOWN을 확인. 파일 누락·잘림·SHA 불일치·다른 세대·HEAD 소실·잘못된 스키마·중복 Actor/아이템·귀속·영수증 오류 거부. 이전 정상 세대 복구 시 새 epoch 강제 |
| Android Cloud 디버그 APK | PASS | org.spdcoop.dungeon.indev, 4.0.2-INDEV (922), min SDK 21, target SDK 36, 36,842,183바이트. aapt 및 apksigner v1/v2 검증과 SHA-256 재검사 통과 |
| GitHub 호스팅 CI / Artifact | NOT RUN | 개발 브랜치를 일반 푸시했으나 해당 브랜치 run 조회에서 0건 |
| Android 실기기 | NOT RUN | 설치, 렌더링, 터치, 실제 Wi-Fi·핫스팟, 앱 생명주기와 전원 차단 내구성 |

**발견한 오류와 재검증.** 첫 7A 검사 한 건은 FAIL이었다. 아이템을 내려놓는 행동에서 몬스터 AI가 표적을 다시 선택했는데 테스트가 이전 표적을 기대했다. 저장 직전의 실제 표적을 확정하고 같은 Actor를 복원하는 검증으로 수정했다. 최종 결과에 해당 실패 실행을 합산하지 않았다. 손상된 현재 세대가 정상 백업을 밀어낼 수 있는 경우도 검토해 백업 승격 전 무결성을 재확인하고 이를 회귀로 고정했다.

**주요 변경 파일과 진입점.** 이 단계의 전체 경로는 ZIP의 `changed-files.txt`에서 확인할 수 있다.

| 영역 | 클래스와 주요 메서드 |
|---|---|
| 원본 엔진 저장 | Dungeon.worldState/restoreWorld, CoopSession.checkpoint/restore/load, Actor.schedulerState/restoreSchedule, Random.worldState/restoreWorld |
| 플레이어·객체 상태 | FloorKnowledge.save/load, ItemOwnership.restored, Bag.restoreFromBundle, Char.add, Heap·Foresight와 Level의 복원 경로 |
| 디스크·인증 | CoopSaves.sessions/inspect, Slot.read/publish, SeatCredential.generate/enroll/reconnect, LanRoom.persistentGame/resume/saveAndClose |
| 행동·표시 모델 | RoomSync.checkpoint/restore/lookup, SeatProjection.resetHandles, SeatActions의 복구된 발급 상한, DisplayReplica.confirmReconnect, LanTransport의 연결별 nonce |
| 신규 검사 | CheckpointTest, GenerationTest, ReconnectTest, HostRestartTest, LedgerChecks, RestartHost, RestartClient |

**실행 명령.** 단계별 Gradle 명령, 원격 조회, 변경 검사 및 푸시 명령은 ZIP의 `commands.txt`에 있다. 최종 실행에 사용한 명령은 다음과 같다.

```bash
scripts/verify-android-build.sh /workspace/deliverables/phase7-final
git diff --check
git push coop coop/phase7
gh api 'repos/jwgobaek/SPD-Coop/actions/runs?branch=coop%2Fphase7&per_page=2'
```

APK SHA-256은 `c531bb4a0352dd7198d793b49fe1a8ce69505535519ddb5ee60b848ba95c802c`이다. Cloud에 생성한 APK는 `/workspace/deliverables/phase7-final/android-debug.apk`에 있다. Git에 보존한 검증 ZIP의 SHA-256은 `9185756fdbf5a0fd6487767b71131c4a800c3a8223d62139c76782b0e00a476d`이다. [검증 ZIP과 JUnit XML](docs/coop/phase7-cloud-evidence.zip)

## Phase 8 첫 층 협동 알파 검증

| 판정 | 실행 및 범위 | 결과 |
|---|---|---|
| PASS | 작업 전 원격 coop/phase7과 원본 회귀 | 917128396fd394eed536f1947072b4effbeb6b62, JUnit 44/44 |
| PASS | 8A 원본 타이틀·로비·저장 컨트롤러 | 8c3f2ab, JUnit 45/45 |
| PASS | 8B 보존 APK의 전체 회귀 | 4c4dc1c, JUnit 47/47. 렌더링 시험을 확장한 4522c95에서 실제 지도 포인터 공격·부활 및 디스크 재개까지 확인 |
| PASS | 8C 일반 문·소형 식량·공개 상태 전송 | 7c2ff38, JUnit 49/49. 원본 이동·음식 소비·행동 비용, 두 좌석과 디스크 복원, 게스트 재접속 검증 |
| PASS | 최종 첫 층 알파 | 6649af1dd625385009bb1aee3bc8f1dff06d422f, JUnit 50/50. 기준 44개 testcase ID 모두 포함, 실패·건너뜀 0 |
| PASS | 추가된 6개 사례 | 로비·양 좌석 및 손상 백업·epoch 복귀, UDP 검색·빈 결과·직접 연결 오류·시작 전 종료, 디스플레이 RNG 격리, 기본 지도·가방 명령, 일반 문·소형 식량·재접속, 두 좌석 행동 비용과 디스크 복원 |
| PASS | 독립 JVM + 실제 TCP + 가상 X11에서 LWJGL3 | 영어·한국어 각 12장. 원본 싱글 진입, 협동 방 생성, 직업·준비, 이동, 가방 식사, 쥐 공격, 앙크 부활, 전투 경계, 저장 목록, 다른 게스트 JVM의 좌석 인증·다음 행동 |
| FAIL | 개발 중간 실행 | 동시 Gradle 작업이 공유한 클래스 파일로 첫 전체 빌드에서 RuleIntegrationTest 클래스 로딩 실패. 6e3abd8 전체 실행에서는 자동 클라이언트의 다음 좌석 대기 및 싱글 스케줄러 대기 각 1건 실패 |
| NOT RUN | GitHub Actions·Android 실기기·전체 협동 완주 | 이 브랜치의 호스팅 실행 0건. 기기 설치·터치·렌더링·무선 LAN·생명주기·실제 저장소 지연, 미지원 층·퀘스트·상점·보스·승리 미검증 |

검증 빌드를 각각 독립된 체크아웃으로 옮겼다. Headless 싱글 스케줄러 시험은 GameScene의 유휴 Actor 깨우기를 재현하고 Hero.ready와 스레드 대기 상태를 함께 확인한다. 기존 시간·버프·종료 단언은 유지했다. 독립 클라이언트의 입력을 실제 시간 간격으로 보내고 타임아웃 진단에 양쪽의 버전을 남겼다. UI는 페이지 전송이 연속된 턴 변경과 겹치면 검증한 마지막 모델을 보존하고 제한된 횟수만 다시 요청한다. 첫 클라이언트 타임아웃에서는 정확히 어느 프레임에서 지연됐는지 확인할 기록이 없었다. 조사용 개별 실행 8회 및 수정 뒤 두 번의 전체 검증을 통과했다.

### 행동과 비용

별도 클라이언트 JVM의 지도 및 가방 명령은 시나리오당 PICK_UP, DROP, PICK_UP, EAT, UNEQUIP, EQUIP, ATTACK, MOVE, REVIVE, WAIT 각 순서로 총 10건이었다. 그 밖의 턴 진행용 대기는 따로 집계했다. 각 부활은 앙크 1개를 소비하고 HP 17에서 5로 회복했다. 단계 5~7의 소켓 회귀도 같은 검증에 포함했다. 상세 수치는 SyncIntegrationTest, RuleIntegrationTest 및 HostRestartTest의 XML에 있다.

| 첫 층 시나리오 | 확정 입력 + 보조 대기 | 입력→영수증·모델 갱신 중앙값 / p95 (ms) | 두 좌석 누적 TCP 바이트 | 마지막 게스트 전체 스냅샷 (바이트) | 자식 JVM 사용 힙 (바이트) / live threads |
|---|---:|---:|---:|---:|---:|
|일반 식량|10 + 대기 11|46 / 86|30907|1715|9488472 / 7|
|소형 식량·문·재접속|10 + 대기 11|25 / 272|39319|1718|10497264 / 7|

같은 첫 층에 대해 내구성 있는 명시적 저장 20회의 중앙값은 7.494 ms, p95는 30.030 ms였다. 입력 지연은 각 10개 관측치, p95는 nearest rank를 사용했다. TCP 계수에는 성공적으로 완료한 프레임과 길이 헤더가 포함된다. 스냅샷 크기는 페이지로 나누기 전 해당 좌석에 허용된 ASCII 데이터다. 장시간 테스트 JVM의 1초 간격 관측값은 RestartHost 42회, 스레드 23~24개, RSS 80,380~313,644 KiB / RestartClient 41회, 스레드 18~21개, RSS 72,280~116,568 KiB다. JVM 내부 작업 스레드를 포함한다. 화면 닫기 후 해당 클라이언트·엔진·LAN 작업자 종료를 확인했다. 클라우드 측정 위치와 시나리오 밖의 지연·메모리 누수 상한은 미검증이다.

### 실행과 산출물

```bash
git ls-remote coop refs/heads/coop/phase7 refs/heads/coop/phase8 refs/heads/master
./gradlew --offline :core:cleanTest :core:test
./gradlew --offline :desktop:compileTestJava :desktop:release
scripts/verify-android-build.sh /workspace/deliverables/phase8-ui
scripts/verify-android-build.sh /workspace/deliverables/phase8-verified
scripts/verify-android-build.sh /workspace/deliverables/phase8-final
python3 scripts/coop-content-inventory.py
git diff --check
git push coop coop/phase8
```

Desktop 실행 명령과 X11 전제는 BUILD.md에 있다. 시험은 실제 생성한 시드 402의 층에서 시작한다. 부활·경계 검증 구간에서는 호스트 테스트가 쥐·앙크·치명상을 배치했고 판정과 자원 소비, 후속 공격·저장·재접속은 실제 코드로 실행했다. 정상 플레이의 임의 시점에서 앙크와 부활 기회가 항상 제공된다는 검증은 아니다.

| APK | 빌드 커밋 | 크기 (바이트) | SHA-256 |
|---|---|---:|---|
| 4.0.2-INDEV-p8 UI 체크포인트 | 4c4dc1cf377815015833d3e151875f02fc1a3120 | 35,224,012 | 19c1f07936cd1316b415a8affbee3712478b3a2ce83cd0f9376eeae29c6271e2 |
| 4.0.2-INDEV-p8c1 최종 첫 층 알파 | 6649af1dd625385009bb1aee3bc8f1dff06d422f | 35,224,379 | 7f7c85982bf0cadbd524edcd776b9d48b22a251a64b1f5d2f652974a382e3b03 |

두 APK 모두 org.spdcoop.dungeon.indev, versionCode 922, minSdk 21, targetSdk 36이다. aapt 패키지 검사와 apksigner의 v1·v2 검증에 통과했다. 서명 인증서 SHA-256은 0dd9070b5f17192a8b07e5ddb6735161b0d2bb6e49013e4d61ca5ee6216ddb53이며 기존 Cloud 디버그 키와 일치했다. 빌드 환경이 바뀌면 같은 키가 있는지 확인해야 한다. iPad에서 볼 수 있는 GitHub 검증 ZIP에는 빌드 로그·JUnit XML·화면·파일 목록이 있다. APK는 Cloud의 /workspace/deliverables/phase8-final/android-debug.apk 및 /workspace/deliverables/phase8-ui/android-debug.apk에 있다. [검증 ZIP](docs/coop/phase8-cloud-evidence.zip)


## 마법사 시작 지팡이 및 하수도 왕복

기준 브랜치 coop/phase8의 원격 HEAD는 시작 시 92ebf943ceb40fe0c63f149f6be9f6ec3e71fa8d였다. 변경 전 깨끗한 별도 체크아웃에서 50건을 실행했다. 엔진 변경과 증거 문서 커밋을 분리했다.

| 검증 | 결과 | 실행 결과 |
|---|---|---|
| 기준 회귀 | PASS | 50건 |
| 8C-2 JUnit 및 APK | PASS | 52건, 693b0b997d73, 35,226,848바이트, SHA-256 `7c88193e226d1b5d837a262e338ee9f15d52de405f60410d298506ca11be8cad` |
| 8D-1 JUnit 및 APK | PASS | 57건, 0d06cfe84426, 35,234,290바이트, SHA-256 `792ee83464d47916ba40a1916b71352594877a54c1b3d0ba9677a117d3b07b3c` |
| 영문·한국어 Desktop | PASS | 실제 LWJGL, 가상 X11, 기존 Noosa 제스처. 마법사 선택·표적 취소·발사·저장·재접속 및 층 이동 동의·하행·상행 |
| 알파 저장본 전체 마이그레이션 | PASS | 이전 커밋으로 저장 후 새 호스트에서 전환. 양쪽 기존 키 인증, 동일 영수증·몹·HP·스케줄러·RNG 스택·귀속·탐험 기억, DOWNED 이후 부활, 원본 세대 보존 |
| 호스팅 GitHub Actions | NOT RUN | 해당 브랜치 실행 기록 0건 |
| Android 설치·화면·터치·생명주기·Wi-Fi·핫스팟·성능 | NOT RUN | 실제 기기 미사용 |

두 APK의 패키지는 org.spdcoop.dungeon.indev, versionCode 922이고 버전명은 4.0.2-INDEV-p8c2와 4.0.2-INDEV-p8d1이다. 두 파일 모두 apksigner v1·v2 검사가 통과했다. 이전 알파와 같은 디버그 서명 인증서 SHA-256은 0dd9070b5f17192a8b07e5ddb6735161b0d2bb6e49013e4d61ca5ee6216ddb53이다.

**실제 네트워크 및 디스크**. 시작 지팡이를 호스트·게스트 각각에 배정해 발사, 재접속, 동일 행동 재전송, 내구성 확정 직후 응답 전 호스트 강제 종료와 재개 후 새 발사를 확인했다. 하수도 시험은 원본 시드 415에서 정상 행동을 실제 소켓으로 전송했다. 시험 안내기가 원본 지도를 읽어 경로를 골랐으며 맵·캐릭터 위치를 바꾸지 않았다. 최종 실행의 이동은 76회, 근접 공격은 13회, 마력탄은 1회, 탐색은 1회였다. 식량 드롭·수량 보존·재획득, 계단 동의·취소, 영수증 재조회는 각각 별도로 확인했다. 하강 HEAD 발행 직후와 상승 HEAD 교체 직전에 실제 호스트를 강제 종료했다. 첫 경우는 2층에서 같은 영수증을 돌려줬고, 둘째 경우에는 2층 그대로 미확정 UNKNOWN을 확인했다. 새 동의 후 1층에 복귀했다. 현재 세대를 손상시켜 명시적인 백업 복구와 새 epoch를 검증했다. Desktop 계단 화면은 별도 준비 코드가 두 영웅을 원본 계단 옆에 놓은 후 실제 동의·이동·재접속 입력으로 촬영했다.

**Cloud 성능**. 각각 21회 같은 상태에서 명시적으로 저장했다. 측정에는 동기화된 파일 쓰기·검증·HEAD 발행이 포함된다. 세대·디렉터리는 측정 시점의 바이트 수이고 힙은 호스트 JVM 한 시점의 사용량이다.

| 조건 | 중앙값 | 95백분위 | 세대 / 디렉터리 | JVM 힙 |
|---|---:|---:|---:|---:|
| 활성 1층만 저장 | 13.19 ms | 32.07 ms | 55755 / 111574 B | 101151480 B |
| 활성 2층과 휴면 1층 저장 | 16.87 ms | 26.6 ms | 112132 / 224328 B | 22139512 B |

이동·전투·식량 행동의 ACK 96건에서 중앙값 14.24 ms, 95백분위 35.37 ms였다. 계단 상승 한 번의 확정 응답은 29.6 ms였다. 이전 7.5/30 ms의 단일 층 시험과 세계 상태·JVM·실행 부하가 다르다.

**발견 및 수정**. 초기 마법사 장착 시험은 싱글플레이 배지 조회에서 실패했다. 협동 장착이 그 경로에 들어가지 않게 수정했다. 첫 층 숨은 입구는 협동 화면에서 제공하는 원본 탐색으로 찾도록 했다. 휴면 층을 복원할 때 원본 게임이 이미 읽은 문서 아이템을 여과해 소유권 개수가 달라지던 오류를 협동 복원 경계에서 수정했다. 특수 방의 희생 제단은 렌더링 전용 emitter에 접근하기 전에 존재 여부를 검사한다. 미지원 목적지에 대해서는 이동 전 확정 상태를 복원한 뒤 명시적으로 거절하는 시험이 통과했다.

실행 명령은 `git ls-remote coop`, `./gradlew --offline :core:test`, `scripts/verify-android-build.sh <결과 디렉터리>`, `python3 scripts/verify-alpha-migration.py /tmp/spd-c2-base`, `./gradlew --offline :desktop:compileTestJava :desktop:release`, `CoopRenderSmoke <드라이버 출력> mage|floors` 및 일반 `git push coop …:refs/heads/coop/phase8`였다. APK 검사 상세, JUnit XML, 실제 스크린샷, 로그, 성능 원자료와 파일 목록은 [검증 ZIP](docs/coop/phase8-mage-floors-evidence.zip)에 있다.

## 하수도 S1 특수 방과 교전

작업 시작 시 coop/phase8 원격과 깨끗한 작업공간의 커밋은 8fe0ee0900c2bef9aa8eabed2fbaed4c8685a47c였다. 기존 회귀 57건을 먼저 재실행해 PASS를 확인했다. 각 검증은 실제 엔진·소켓·파일을 사용했다.

| 클라우드 검사 | 결과 | 회귀 수 | 빌드 커밋 | APK 크기 | SHA-256 |
|---|---|---:|---|---:|---|
| red-sentry | PASS | 61 | 5b39c9d4b071 | 35,234,870 B | `52cd197e85017cf6e185bec5b58c90230a48ec1276a53f0e24cb95acba40e1a9` |
| sad-ghost | PASS | 63 | ee9e6095f483 | 35,237,730 B | `94e0be62aa37d6092591e9da6253a9037bb61d7fa66ee3e506ac0ae24b21c68a` |
| hive | PASS | 65 | 3765d34f09f5 | 35,238,756 B | `6e89e773e866549216f01c9a2024db7d4edd5794bf2483187b06c311b3ecc0ad` |
| sewer-region | PASS | 66 | 90410ac426fb | 35,238,975 B | `363fc642ab55bd7d80b56f28f38c0841a01cbd58469b1fe76d58745b9f31f511` |

최종 버전은 4.0.2-INDEV-sewer-hive, 패키지는 org.spdcoop.dungeon.indev, versionCode는 922이다. 네 APK에서 apksigner v1·v2 검사와 기존 서명 인증서 SHA-256 `0dd9070b5f17192a8b07e5ddb6735161b0d2bb6e49013e4d61ca5ee6216ddb53` 일치를 확인했다.

| 실제 실행 경로 | 결과 | 확인 범위 |
|---|---|---|
| 생성 조사 | PASS | 연속 22시드 × 5개 층, 총 110층. 5층은 원본 SewerBossLevel 생성까지 |
| 계단 인접 배치, 기존 월드 복원 | PASS | 22시드 중 15개 하행·복원·상행. 7개는 목적지 거부 후 기존 1층 지도·RNG·턴 복원 및 다음 행동 성공. 거부 시드 405, 408, 411, 413, 416, 420, 421 |
| Sentry·Piranha | PASS | 양쪽 좌석에 대한 개별 엔진 교전, 단일 빔·재충전, 다운과 별도 좌석 HP, 수중 이동·원본 고기, 층 왕복 |
| Sad Ghost·FetidRat | PASS | 월드 의뢰 수락, 마력탄·원본 피해, 무기·방어구 선택, 동일 월드 보상 1회. HEAD 직후 응답 전 호스트 강제 종료, 새 JVM에서 보상 영수증 조회·재전송 |
| Bee·Honeypot | PASS | 원본 방의 벌과 별도 소환, 수령·깨기·드롭·아이템 귀속, 다른 층에 놓은 조각·벌 ID 대조. TCP에서 인증 후 같은 행동 재전송 |
| 높은 풀 | PASS | 양쪽 좌석 사냥꾼이 밟은 높은 풀이 이랑으로 바뀌고 복원 뒤 전사가 밟으면 원본 일반 풀이 됨 |
| 실제 Desktop | PASS | 같은 제품 소스의 3765d34에서 KO·EN 각각 감시탑 충전 및 재개, 유령 대화·수락·재개. 원본 방에 교전 좌표를 미리 배치한 LWJGL/X11 입력 시험 |
| GitHub Actions | NOT RUN | GitHub API에서 해당 브랜치 실행 기록 0건 |
| Android 설치·화면·터치·Wi-Fi·핫스팟·성능 | NOT RUN | Android 기기 미사용 |
| 3~5층 협동 진행·Goo 전투·6층 진입 | NOT RUN | 3~5층은 원본 생성만 조사. 6층 생성·진입도 미실행. 지원 저장 범위는 1·2층 |

**TCP 행동 집계**. 최종 66건 회귀에 포함된 HostRestartTest의 원자료를 사용했다. 계측 커밋 b45fce8에서 자식 JVM 로그의 행동 수와 스냅샷 크기를 함께 보존하도록 고쳤다. 특수 방 시나리오별로 성공 응답을 실제로 받은 게임 요청 수를 기록했다. 이동·기다림·도구 조작을 포함한다. 아래 인증 횟수에는 초기 참가가 포함되지 않는다. 조회·재전송과 응답 전 종료는 성공 응답 수에서 제외한다.

| 시나리오 | 성공 응답 | 재접속 인증 |
|---|---:|---:|
| sentry | 5 | 4 |
| piranha | 3 | 2 |
| quest | 11 | 0 |
| questreceipt | 1 | 2 |
| hive | 8 | 4 |

소켓 특수 방에서는 감시탑과 피라냐의 게스트 피해 및 호스트 HP 불변, 유령 의뢰 수락·전투·보상 한 건, 꿀단지 하나의 획득·깨기·드롭을 구분해 검사했다. 보상 영수증 재조회는 새 보상으로 집계하지 않았다. 시드 415의 원본 경로에서는 이동 121회, 근접 요청 18회, 탐색 1회, 마력탄 1회를 확인했다. 기존 soak의 1000회는 저장·재접속 회귀 범위에 속한다. 개별 방의 위치 배치, 피라냐 전리품 시험의 직접 치명상, 양 좌석 의뢰 전투 조건은 [시드별 검증 설명](docs/coop/sewer-region.md)에 기록했다.

**클라우드 비용**. 시드 415, 동일 상태에서 층별 명시적 저장 21회. 휴면 레코드는 비압축 UTF-8 바이트다. 세대와 슬롯은 실제 디스크 파일 크기, 힙과 Actor 수는 측정 시점의 호스트 값이다.

| 활성 층 | 활성 Actor | 휴면 레코드 B | 저장 세대 / 슬롯 B | 저장 중앙값 / p95 ms | 사용 JVM 힙 B |
|---|---:|---:|---:|---:|---:|
| 1 | 17 | 0 | 55793 / 111650 | 13.05 / 24.30 | 92965376 |
| 2 | 17 | 37303 | 114377 / 228818 | 13.49 / 21.84 | 41864312 |

원본 경로의 행동 응답 149건은 중앙값 12.28 ms, p95 27.26 ms였다. 계단 상행 응답 한 건은 25.06 ms였다. 특수 방 5개 소켓 시나리오에서 마지막 공개 모델의 두 좌석별 전체 스냅샷은 785–2,559 ASCII 바이트였다. 각 수치는 Cloud에서만 측정했다. 이전 1·2층 빌드 0d06cfe의 저장 중앙값/p95는 1층 13.19/32.07 ms, 2층 16.87/26.60 ms였다. 실행 시점의 JVM 부하와 상태가 달라 직접 성능 향상을 판단하기 어렵다. Goo 협동 처리 시간은 NOT RUN이다.

**발견 및 수정**. 9ce097c 전체 검사에서 퀘스트 몬스터가 높은 풀 전리품의 빈 스프라이트에 접근해 FAIL했다. 원본 아이템 드롭을 유지하고 Heap.animateDrop으로 시각 완료를 분리한 ee9e609에서 63건이 통과했다. 94facc5 전체 검사에서는 주소 오류 후 메뉴 복귀를 검사하는 도우미가 비동기 작업 도중 직전 DISCONNECTED 화면을 읽어 64건 중 한 건이 FAIL했다. 작업 완료 후 게시된 Frame을 읽도록 순서를 고쳐 주소 오류와 메뉴 복귀 양쪽 검증을 유지했다. 3765d34에서 65건, 계단 다중 시드 시험을 추가한 90410ac에서 최종 66건 모두 PASS다.

실행한 주요 명령은 `git ls-remote coop`, `./gradlew --offline :core:test`, `scripts/verify-android-build.sh <결과 디렉터리>`, `python3 scripts/coop-content-inventory.py`, `./gradlew --offline :desktop:compileTestJava :desktop:release`, `CoopRenderSmoke <출력> sentry|ghost`, `gh api repos/jwgobaek/SPD-Coop/actions/runs`, `git diff --check`와 일반 `git push coop HEAD:refs/heads/coop/phase8`이다. 키·개인 저장 데이터를 제외한 로그, JUnit XML, 성능 원자료와 실제 화면은 [검증 ZIP](docs/coop/sewer-specials-evidence.zip)에 있다.

## 하수도 S1 미믹·석상 클라우드 검증

기준 8bc710b의 66개 JUnit 케이스를 작업 전에 다시 실행하여 PASS를 확인했다. 최종 소스 c67af0f의 82개가 모두 PASS이며, 기존 케이스 66개의 이름을 XML에서 대조했다. 실패·오류·건너뜀은 모두 0건이다. 일반 미믹 3bfbc2d는 69건, 수정 미믹 1169837은 72건, 석상 2d48744는 77건과 각 Android APK 검사를 통과했다.

| 시험 | 결과 | 실제 범위 |
|---|---|---|
| 일반 미믹 | PASS | 양 좌석 열기와 원본 기습·마력탄 선공·피해·금화, 노출 전 h셀, 주차된 층 및 재연결 영수증 |
| 수정 미믹 | PASS | 양 좌석 탈취, 훔칠 수 없는 경우, 원소유권을 유지한 스택 분리·반환·병합, 영구 도주 및 새 JVM 복원 |
| 수정 미믹 장애 복구 | PASS | 다른 호스트 JVM 7개. 탈취와 처치의 HEAD 직후 응답 전에 강제 종료 2회. 두 좌석이 다시 인증해 기존 영수증을 조회했다. 도주 중·층 이탈·귀환·처치·재획득을 구분했다. |
| 석상·GnollExile·유령 피라냐 | PASS | 특정 원본 장비와 피해·귀속, 실제 420의 독립 몹, 479의 물속 순간이동과 원래 고기. TCP에서 게스트의 마력탄과 재인증 후 확정 영수증 대조 |
| 원본 22개 계단 배치 | PASS | 21/22 왕복. 421은 REJECT_FLOOR 뒤 지도·턴·RNG 원복 및 다음 행동 성공 |
| 추가 연속 표본 및 희귀 지정 표본 | PASS | 424–445는 17/22 왕복. 479는 1/1. 거부된 목적지와 처음부터 미지원인 1층을 구분했다. |
| 시드 421의 실제 2층 진입 | FAIL | 원본 Statue/Scimitar/Unstable이 미지원이며 S1 완료 조건이 남아 있다. |
| Desktop UI | PASS | X11·LWJGL 실제 KO·EN 화면. 일반 미믹 공개, 수정 미믹 탈취 후 화면, 석상 전투와 재인증. 교전 위치는 시험용으로 준비했으며 공격·도주 프레임 및 소리 전체의 정확성은 미검증이다. |
| S2 다트 함정 및 열쇠 소비 | NOT RUN | S1 완료 후 착수 조건이 남아 있다. |
| Android APK 빌드·검사 | PASS | 4.0.2-INDEV-sewer-guardians, versionCode 922, org.spdcoop.dungeon.indev, 35,241,857 B, v1·v2 서명 |
| Android 설치·터치·화면·Wi-Fi·핫스팟 / GitHub Actions | NOT RUN | 실기기 미사용. 호스팅 브랜치 실행 조회 0건 |

APK의 SHA-256은 `a42c377d3cccec96e36a581c65cf263cbc158a10907334793672db224ffd1537`, 기존 개발 서명 인증서 SHA-256은 `0dd9070b5f17192a8b07e5ddb6735161b0d2bb6e49013e4d61ca5ee6216ddb53`이다. 빌드 커밋은 `c67af0fdd620bb7a96a4e1c7e49a157ee1e3efc6`이다.

**좌석·영수증 검증.** 독립 클라이언트 JVM에서 실제 성공 응답을 받은 게임 행동을 집계했다. 재조회와 응답 유실 시점의 확정 행동은 성공 응답 수에서 제외한다. 수정 미믹 시나리오의 성공 응답은 10건, 기존 좌석 재인증은 18회다. CPU·메모리를 공유하는 모의 호스트는 사용하지 않았다.

| 실제 TCP 모드 | 성공 응답 행동 | 재인증 |
|---|---:|---:|
| mimic | 4 | 0 |
| mimicreceipt | 1 | 2 |
| crystal-fight | 2 | 8 |
| crystal-final | 1 | 2 |
| crystal-loot | 1 | 2 |
| crystal-new | 4 | 0 |
| crystal-open | 0 | 2 |
| crystal-park | 1 | 2 |
| crystal-return | 1 | 2 |
| statue | 5 | 2 |
| exile | 5 | 2 |
| phantom | 5 | 2 |
| blocked-start | 0 | 0 |

**시작 위치부터의 경로.** 원본 1층에서 출발해 실제 동의·층 이동, 디스크 엔진 복원·1층 복귀 후 다음 행동을 수행했다. 안내기는 원본 지도를 읽는다. 교전 위치에 배치하여 특수 Actor를 시험한 횟수와 구분한다.

| 시드 | 이동 | 근접 | 탐색 | 마력탄 |
|---:|---:|---:|---:|---:|
| 408 | 58 | 4 | 2 | 5 |
| 411 | 92 | 10 | 1 | 5 |
| 415 | 74 | 7 | 1 | 0 |
| 416 | 42 | 6 | 2 | 1 |
| 420 | 58 | 6 | 1 | 4 |

특수 Actor와 두 좌석별 공개 전체 스냅샷 크기는 744–2026 ASCII 바이트였다. 다음은 클라우드의 시드 415 독립 소켓 시험에서 기록한 원자료다. 명시적 저장과 행동 확정 응답은 별도 측정이다.

```text
native socket route action_ack_count=100 median_us=14662 p95_us=25718
native socket route moves=76 melee=15 searches=1 casts=1
floor=1 explicit_disk_saves=21 median_us=23913 p95_us=90286 generation_bytes=55754 slot_bytes=111572 active_actors=17 parked_utf8_bytes=0 host_used_heap_bytes=91797480
floor=2 explicit_disk_saves=21 median_us=15942 p95_us=23552 generation_bytes=112230 slot_bytes=224524 active_actors=17 parked_utf8_bytes=37287 host_used_heap_bytes=11495328
ascent_ack_us=31371
```

**발견 및 수정.** 기습 경로가 입력 준비 상태에 의해 중단될 수 있어 CoopSession.act가 원본 Mimic.interact에 실제 영웅을 넘기도록 수정했다. 미믹 내부 물건과 석상 보유 무기를 휴면 층의 물리적 ID 검증에 추가했다. 추가 표본에서 1층이 미지원 석상을 생성하는 경우가 확인돼 시작 전에 검사하고 로비로 돌려보낸다. 시험에서는 흡혈 회복이 같은 입력 경계에서 피해량을 가릴 수 있어 석상 첫 마력탄을 원거리에서 검사한다. 전리품은 쌓임·낙하 후에도 수량을 비교한다. 중간 b29bc85에서는 시드 415 TCP 안내 경로의 변화로 80건 중 1건이 FAIL했다. 기준 시드 안내 정책을 원복하고 새 시드용 경로 선택만 분리했다. 미시작 로비를 저장하려던 시험 종료 루틴은 정상적인 저장 거부까지 검사하도록 고쳤다. Desktop JAR을 읽는 중 재빌드하면 Ogg 리소스 읽기 오류가 발생해 최종 JAR을 고정하고 다시 검증했다.

주요 명령은 `git ls-remote coop refs/heads/coop/phase8`, `./gradlew --offline :core:test`, `scripts/verify-android-build.sh <output>`, `./gradlew --offline :desktop:compileTestJava :desktop:release`, `CoopRenderSmoke <dir> mimic|crystal|statue`, `python3 scripts/coop-sewer-survey.py <junit> [--gates]`, `python3 scripts/coop-content-inventory.py`, `git diff --check` 및 일반 Git push다. [검증 자료 ZIP](docs/coop/sewer-guardians-evidence.zip) · [원본 생성 110개](docs/coop/sewer-generation.tsv) · [45개 시드의 계단 결과](docs/coop/sewer-gates.tsv)
