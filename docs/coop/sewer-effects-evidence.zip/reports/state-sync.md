# Phase 5 동기화 프로토콜 SYNC1

## SYNC11 공개 상태

keys는 현재 층의 파티 철 열쇠 수량이다. h셀의 LOCKED_CHEST는 실제 잠긴 상자와 위장 중인 황금 미믹이 공유한다. 해당 셀은 발견 전 m·z·보상 행을 생성하지 않는다. 직접 관측하는 셀에서만 공개하는 trap셀 값은 원본 색+16×shape, cloud셀은 Fire=1, Freezing=2, Electricity=4, ToxicGas=8, ConfusionGas=16의 비트 합이다. 관측을 잃으면 동적 행을 지운다. Sheep과 모습을 드러낸 GoldenMimic은 직접 보이는 경우에만 표시한다.

## 방과 연결

호스트의 엔진 스레드는 `LanRoom.synchronizedGame(bind,tcp,udp,seed)`로 방을 만들고 pump한다. 각 클라이언트는 `LanClient.synchronizedGame(address)`로 연결한다. 기존 v1 길이 헤더와 HELLO 뒤에 MODE SYNC1을 보내고 같은 응답을 확인한 뒤 HOST 또는 JOIN을 보낸다. 일반 v1 방과 동기화 방은 서로의 참가 방식을 거부한다. 동기화 방에서는 기존 ACT를 쓸 수 없다. UDP 광고와 로비의 SELECT·READY·START는 Phase 4와 같다.

엔진은 두 영웅을 생성해 첫 입력 차례가 준비되면 버전 1을 확정한다. 이후 하나의 DO를 실행하고 다음 입력 차례가 준비됐을 때 양쪽 공개 상태를 함께 확정한다. 사이에 처리된 몹·버프·회복도 이 경계에 포함한다. TURN과 stateVersion은 별도 카운터다. 재생 시간 재조정, 조회·PING, 사전 검증 거부, 동일 결과 반환은 버전을 소모하지 않는다. 단절·엔진 중단에 따른 일시정지는 한 번 확정한다.

## 행동과 결과

```text
1 rid session DO player seat actor actionID baseVersion turn verb cell itemID
1 rid RESULT actionID seat actor requestedTurn requestedBase committedVersion outcome
```

바깥 rid는 연결마다 증가하는 전송 번호다. 동일 논리 행동을 재전송할 때 rid만 새 번호가 된다. actionID는 세션·좌석별 양의 long이다. 입력은 2,048바이트 이내이며 DO만 13개 토큰을 쓴다. 문자열 표현이 다른 숫자도 파싱한 수치로 비교한다. 동기화 방의 아이템 ID는 v1 STATE의 턴별 핸들과 구분한다.

1. 세션 UUID, 실제 연결의 좌석, player 및 해당 영웅의 Actor ID부터 확인한다.
2. 좌석별 최근 64개의 행동 기록에서 ID를 찾는다. 같은 base·turn·verb·cell·item이면 저장된 RESULT를 반환하고 다른 내용이면 ERROR CONFLICT다. 기록이 밀려났지만 처리한 최고 ID 이하인 요청은 ERROR EXPIRED다. 이전 세션이나 다른 좌석의 결과를 조회할 수 없다.
3. 새로운 ID면 버전·턴·소유권과 실제 CoopSession.act의 이동·공격·소비 조건을 검사한다. RESULT의 REJECT_VERSION/TURN/ITEM/INVALID/ACTION/PAUSED는 거부다. 인증된 새 ID의 거부 결과도 64개 한도에 포함된다. 사용하지 않은 작은 번호를 나중에 제출할 수 없다.
4. APPLIED는 정상 확정, APPLIED_STOPPED는 승인된 행동 후 엔진이 정상 중단 조건을 보고한 경우다. HALTED_UNCERTAIN은 실행이나 확정 중 예외가 발생해 일부 효과가 이미 반영됐을 수 있다는 뜻이다. 재실행이나 롤백을 시도하지 않는다. PAUSED 모델은 행동권과 플레이 중의 지도를 제거한다. 공개 사유는 DISCONNECTED, ENGINE_STOPPED, ENGINE_ERROR 중 하나이며 예외 전문은 호스트에만 둔다.

영수증에는 좌표·다른 사람의 인벤토리·전체 상태를 싣지 않는다. 마지막 확정 경계가 자신의 행동이면 자신의 모델에만 receipt 행이 들어간다. 이 캐시와 최고 ID는 방의 메모리에 있다. 캐시 밖의 과거 결과나 완전히 끊어진 연결에서의 좌석 복원은 지원하지 않는다.

## 상태 전송

| 요청 | 응답 |
|---|---|
| SYNC 0 NEW | 해당 좌석의 현재 전체 스냅샷 첫 PART |
| SYNC version sha256 | 같은 상태이면 CURRENT version sha256. 직전 버전과 해시가 일치하면 변경분 PART. 그 밖에는 RESYNC |
| PAGE transfer index | 같은 연결·좌석의 활성 전송에서 요청한 PART. 만료·새 확정 경계 또는 전송 교체 후에는 ERROR TRANSFER |

PART는 `PART transfer index count transferSHA256 segment`이다. 인덱스는 0부터 시작한다. 조각은 최대 1,400 ASCII 바이트, 최대 64개, 전체 최대 89,600바이트, 공개 상태 최대 2,048행이다. 마지막 조각을 제외한 길이는 일정하다. 좌석당 현재/직전 공개 상태와 전송 본문 하나만 유지한다. 조립 제한은 5초다. 커밋되면 두 좌석의 이전 전송을 무효화한다. 스냅샷 생성·변경분 생성은 불변 버전을 사용한다. TCP의 길이·속도·큐·열린 연결 제한은 기존 명세를 따른다.

본문은 `S|session|seat|0|version|stateSHA256|operations` 또는 `D|session|seat|base|version|stateSHA256|operations`이다. D는 한 커밋만 전진한다. 일반 동작은 키 단위로 달라진 값만 보낸다. 아주 큰 변경분은 상한 내 전체 스냅샷으로 대체할 수 있다. 연산은 세미콜론으로 끝난다. `+key=value`는 추가·교체, `-key`는 모델에서 제거한다. 몹의 -는 관측 상실이다. `!m<ID>`는 이전에 보였고 직접 근접 공격으로 처치가 확인된 몹이 같은 관측 위치에서 사라졌음을 표시한다. 시야 밖의 죽음은 보고하지 않는다.

## 공개 행

| 키 | 의미 |
|---|---|
| status, turn, active, clock | 세션 상태, 입력 차례, 현재 좌석(-1이면 없음), 원본 누적 시간과 Actor.now의 합 |
| reason, receipt | 일시정지 사유, 행동자 본인의 마지막 확정 경계에 대한 actionID·verb·outcome |
| width, self, ally | 셀 인덱스 해석용 폭. self는 actor·위치·HP·HT·직업·레벨·경험치. ally는 직접 볼 수 있을 때만 actor·위치·직업 |
| t셀, h셀 | 현재 직접 시야 안의 표시 지형, 내용물을 열람할 수 없는 더미의 일반 컨테이너 표기. 비밀 문은 벽, 숨은 함정은 빈 바닥으로 보냄 |
| mActorID | 현재 직접 관측 가능한 지원 몹의 위치·종류·HP·HT. 투명 몹 제외 |
| bActorID | 자신의 표시 아이콘이 있는 버프/디버프의 아이콘과 원본 표시용 남은 시간(FlavourBuff), 기타 NA |
| i좌석별ID | 소유·장착 슬롯 또는 현재 보이는 일반 바닥 더미의 맨 위 셀, 종류(FOOD/MELEE/OTHER), 표시 이미지·수량·알고 있는 강화 수치 |

직접 시야는 원본 Level의 차폐·거리 계산을 공유하며 특수 감지와 기존 탐험 배열을 합치지 않는다. 자기 칸은 포함한다. 아이템 ID는 좌석별로 발급하며 연속해서 공개되는 같은 객체는 바닥→가방→장비로 이동해도 같은 ID다. 스택에 흡수되거나 소모되거나 시야에서 사라지면 해당 좌석의 매핑을 제거한다. 재발견 시 새 ID를 받을 수 있다. 아이템의 ID와 행동 권한은 별도로 검사한다. 다른 사람의 장비·가방 내용, 미관측 지형, 숨은 몹, 월드 RNG, 방장 자격값은 공개 모델과 해시에서 제외한다.

## 표시 모델과 오류 처리

좌석마다 하나의 SeatActions와 DisplayReplica를 유지한다. refresh로 첫 상태를 받은 뒤 UI에는 불변 StateImage를 전달한다. 현재 좌석이라면 SeatActions.prepare로 Pending을 만들고 submit한다. 영수증이 애플리케이션에서 유실되면 같은 Pending을 같은 연결에서 다시 제출한다. 화면을 새로 동기화해도 SeatActions의 번호 생성기는 유지한다.

조각 순서·토큰·개수·시간·전송 해시를 확인한 뒤 임시 맵에 연산을 적용한다. 클라이언트는 **적용한 행**을 키 순서로 정렬해 `session|seat|version|key=value;...`의 SHA-256을 직접 계산한다. 호스트의 공개 상태 해시와 일치할 때만 모델을 교체한다. 동일 변경분은 재적용하지 않는다. 버전 누락·잘못된 순서·손상에는 전체 스냅샷을 한 번 새로 요청한다. 그 시도도 실패하면 마지막 정상 모델을 유지하고 호출자가 오류를 받는다. 실제 전송 연결이 끊겨 refresh가 통신 실패를 받으면 모델을 닫는다. 화면에서 주도적으로 퇴장할 때도 close를 호출한다.

플랫폼 UI, 플레이어별 영구 탐험 기록, 특수 감지, 장기 저장용 아이템 ID와 캐시, 재접속은 후속 단계다.

## Phase 6 좌석별 게임 규칙

SYNC1의 2,048바이트 요청 프레임, 1,400바이트 조각 64개, 상태 2,048행 및 조립 5초 한도를 유지한다. 좌석의 직접 시야·기억 지형·전투 경계가 같은 공개 상태 해시와 원자적 교체에 포함된다. 같은 방에서 전체 재동기화하면 호스트가 보관한 해당 좌석의 기억을 복원한다.

| 행 또는 행동 | 해석 |
|---|---|
| t셀 | 지금 관측하는 지형. 현재 보이는 몹·바닥 아이템 행은 시야를 잃으면 제거된다. 숨겨진 더미에는 아이템·컨테이너 행이 없다. |
| r그룹 | 연속 32셀의 현재 시야 밖 기억을 64 ASCII 문자로 표현한다. 셀 번호를 32로 나눈 몫이 그룹, 나머지가 그룹 안의 위치다. 두 문자 중 첫 문자는 직접 방문 v 또는 지도 효과만으로 파악한 p다. 둘째 문자는 숫자, 소문자, 대문자 순서의 지형 번호다. 빈 쌍은 점 두 개다. 전부 빈 그룹은 생략한다. 시야를 벗어난 몹이나 아이템은 기억 행에 기록하지 않는다. |
| z셀 | 공개된 통행 영역의 테두리. 북·동·남·서에 각각 비트 1·2·4·8을 배정한다. 전역 구역 번호, 참여자 명단, 전체 면적을 전송하지 않는다. |
| life, revivable, allylife | 자신의 ALIVE/DOWNED/DEAD 상태와 부활 가능성. 보이는 동료에 한해 allylife를 보낸다. REVIVING은 자원 소비와 복구 사이의 엔진 내부 상태다. |
| DO … DROP cell itemID | 현재 자신의 위치에 자신의 가방 속 지원 아이템을 한 단위 내려놓는다. 원본 드롭 시간을 사용한다. |
| DO … UNEQUIP 0 itemID | 자신의 지원 근접 무기 장착을 해제하고 가방에 넣는다. 원본 장비 해제 시간을 사용한다. |
| DO … REVIVE cell 0 | 보이는 인접 동료를 부활시킨다. 호스트가 대상, 점유, 자원 소유권을 확인한다. 다른 사람의 비공개 아이템 핸들을 전달할 필요가 없다. 자신의 인벤토리와 관측 가능한 바닥 더미에서는 앙크 종류를 ANKH로 표시한다. |
| PARTY_DEFEATED | 마지막 생존자가 쓰러진 행동의 확정 결과와 최종 status다. active는 -1이다. 그 뒤 새 행동은 REJECT_DEFEATED, 동일 행동의 재조회는 원래 영수증을 반환한다. 엔진 예외에는 기존 HALTED_UNCERTAIN을 사용한다. |

행동·소유권 검사는 CoopSession.act에서 v1과 공유한다. 기존 v1 ACT에서는 세 신규 동사를 ERROR MODE로 거부한다. SYNC1에서는 각 DO의 action ID·base·turn·cell·공개 핸들이 기존 캐시 규칙을 따른다. 투척과 직접 전달 명령은 지원하지 않는다.

## 디스크 복원 경계

영구 방의 모델에는 epoch가 포함된다. 재접속 대기 중에는 status=PAUSED, reason=RECONNECTING, active=-1과 해당 좌석이 확인할 수 있는 전체 공개 상태를 제공한다. 재접속용 새 DisplayReplica에서 전체 스냅샷을 확인하고 체크섬을 호스트에 제출한다. 복원과 단절은 공개 아이템 핸들을 무효화한다. 저장된 발급 상한부터 새 핸들을 할당한다. 영수증은 원본 요청의 핸들 문자열을 보존한다. [재접속 명세](reconnect.md)

## Phase 8 UI

selftier는 자신의 원본 방어구 외형 단계다. allytier는 ally가 공개되는 버전에만 포함한다. 기존 값의 부재는 기본 외형으로 표시할 수 있다. 공개 해시, 버전 및 청크 제한은 기존 SYNC1 규약을 따른다.

다른 좌석의 확정으로 페이지 전송이 바뀌면 클라이언트는 직전 검증 모델을 유지한다. DisplayReplica의 제한된 새 스냅샷 시도와 작업자의 후속 폴링을 사용한다. 유효하지 않은 전송이 세 폴링에 연속되면 연결 오류를 표시한다. 오래된 입력은 버전 검사를 거친다.

## 하수도 특수 방 체크포인트

SYNC6은 시야 안의 Sentry·Piranha·Ghost·FetidRat·Bee와 허용된 아이템 종류를 표시한다. charge<cell>은 충전 중인 감시탑을 직접 볼 때만, quest<cell>은 유령을 직접 보고 인접할 때만, stench<cell>은 현재 시야 안에 가스가 있을 때만 보낸다. 일반 객체와 같은 관측 상실·해시·재접속 전체 스냅샷 검사를 거친다. [메시지 및 동사](lan-protocol.md)

## 상자 위장과 몬스터 보관품

SeatProjection은 중립 미믹을 CHEST 또는 CRYSTAL_CHEST로 표시한다. 위장 상태에서는 해당 Actor의 m행·HP·전리품·공격 상태가 없다. PublicDungeon과 CoopBoard는 두 좌석에서 같은 h셀 입력을 사용한다. 공개 후 직접 볼 수 있는 동안 기존 m행의 위치·HP와 원본 텍스처를 사용한다. 몬스터 보관품의 내부 ID 및 소유자 필드는 디스크 저장에만 존재한다. 귀속품이 바닥으로 돌아오면 공개 item ID와 별개로 호스트가 실제 소유자를 검증한다.
