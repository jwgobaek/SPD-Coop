SPD-Coop V4·V5 / H1·H2 / H6 클라우드 검증
release/junit에는 APK 빌드 시의 원본 JUnit XML이 있다. summary/socket-results.txt에는 실행된 독립 JVM 소켓 시험의 계량 행이 있다.
서로 다른 커밋의 동일 캠페인은 별개의 회귀 실행이다. 세션 간 같은 경로의 행동 수를 합산하지 않았다.
desktop의 PNG는 한국어·영어 LWJGL/X11 실제 게임 화면이다. 감옥·석상·주문서 촬영에는 준비한 게임 상태를 사용했다. 정상 시작 시드 581과 1105의 입력 증거는 JUnit에 있다.
schema4-backup은 APK 소스 이후 보강한 시험으로 세 번째 호스트에서 복구했다. controls 및 kit-slots는 다음 차례의 화면 표시까지 기다리는 검증 드라이버를 사용했다.
observed-image-sizes.tsv는 Linux에서 실제 HEAD가 가리킨 완전한 세대 하나씩을 읽어 측정했다. 휴면 크기는 UTF-8 compact JSON 직렬화, 파일 크기는 헤더와 체크섬을 포함한 디스크 바이트다.
Android 실기기 및 무선 통신과 GitHub Actions는 NOT RUN이다. Android 디버그 APK는 별도 다운로드로 제공한다.
